package atividade6;

public class DaoEvent {
}
